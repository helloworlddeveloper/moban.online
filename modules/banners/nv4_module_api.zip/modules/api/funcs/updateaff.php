﻿<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2014 VINADES.,JSC. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Thu, 19 Jun 2014 09:53:21 GMT
 http://cash13.vn/slidehome/test/?p1=abc&p2=1235
 http://cash13.vn/index.php?nv=slidehome&op=test&p1=abc&p2=1237
 */

if ( ! defined( 'NV_IS_MOD_SLIDE' ) ) die( 'Stop!!!' );
header('Content-Type: application/json');
$p1 = $nv_Request->get_string('p1', 'post',10);
$p2 = $nv_Request->get_int('p2', 'get');
//echo $module_file . ":" . $module_info['template'] . ":";

$array = array(
    "name" => "Nguyễn Văn Cường",
    "email" => "TheHalfHeart@gmail.com",
    "website" => "freetuts.net",
    "p1" => $p1,
    "p2" => $p2, 
);
 
echo json_encode($array);